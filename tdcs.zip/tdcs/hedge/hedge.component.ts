import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hedge',
  templateUrl: './hedge.component.html',
  styleUrls: ['./hedge.component.css']
})
export class HedgeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
