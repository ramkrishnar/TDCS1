import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MbsTicketComponent } from './mbs-ticket.component';

describe('MbsTicketComponent', () => {
  let component: MbsTicketComponent;
  let fixture: ComponentFixture<MbsTicketComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MbsTicketComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MbsTicketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
