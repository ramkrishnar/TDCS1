import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mbs-ticket',
  templateUrl: './mbs-ticket.component.html',
  styleUrls: ['./mbs-ticket.component.css']
})
export class MbsTicketComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
