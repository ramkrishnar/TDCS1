import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes,RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { MbsTicketComponent } from './mbs-ticket/mbs-ticket.component';
import { HedgeComponent } from './hedge/hedge.component';
import { AllocationComponent } from './allocation/allocation.component';
import { BatchComponent } from './batch/batch.component';
const appRoutes:Routes=[
  {path:'mbs',component:MbsTicketComponent},
  {path:'AandD',component:AllocationComponent},
  {path:'Hedge',component:HedgeComponent},
  {path:'Batch',component:BatchComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    MbsTicketComponent,
    HedgeComponent,
    AllocationComponent,
    BatchComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
